"""
Calories Burnt Predictor — Streamlit Web App
------------------------------------------------
A dashboard UI for the Random Forest calorie burn model.

BEFORE YOU RUN THIS:
  1. Install dependencies:
       pip install streamlit pandas scikit-learn matplotlib
  2. Make sure "calories_burnt_data.csv" is in this same folder.
  3. Run with:
       streamlit run app.py
     (NOT "python app.py" — Streamlit apps must be launched with the
     "streamlit run" command.)
"""

import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error

# ---------------------------------------------------------------------------
# Page config + styling
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Calories Burnt Predictor", page_icon="🔥", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #FBF7F2; }
    section[data-testid="stSidebar"] { background-color: #F5E9E3; }
    div[data-testid="stMetric"] {
        background-color: #FFFFFF;
        border: 1px solid #EAD9CE;
        border-radius: 10px;
        padding: 16px;
    }
    div.stButton > button {
        background-color: #E8604C;
        color: #FFF7F2;
        font-weight: 700;
        border: none;
    }
    div.stButton > button:hover {
        background-color: #EF7B69;
        color: #FFF7F2;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Train the model (cached so it only trains once per session)
# ---------------------------------------------------------------------------

FEATURES = ["Gender", "Age", "Weight", "Duration", "Heart_Rate", "Body_Temp"]


@st.cache_resource
def load_model():
    df = pd.read_csv("calories_burnt_data.csv")

    le = LabelEncoder()
    df["Gender"] = le.fit_transform(df["Gender"])

    X = df[FEATURES]
    y = df["Calories_Burnt"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=150, random_state=42)
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    r2 = r2_score(y_test, pred)
    mae = mean_absolute_error(y_test, pred)
    avg_calories = df["Calories_Burnt"].mean()
    return model, le, r2, mae, len(df), avg_calories


model, le, r2, mae, n_rows, avg_calories = load_model()


# ---------------------------------------------------------------------------
# Sidebar — Model Control
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown("## 🔥 Model Control")
    st.markdown("### Model Info")
    st.markdown("🔹 **Algorithm:** Random Forest Regressor")
    st.markdown(f"🔹 **Dataset:** Workout Sessions ({n_rows} rows)")
    st.markdown(f"🔹 **Test R² Score:** {r2:.3f}")
    st.markdown(f"🔹 **Test MAE:** {mae:.1f} kcal")

    st.markdown("---")
    st.markdown("### Settings")
    show_comparison = st.checkbox("Compare to dataset average", value=True)


# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------

st.title("Calories Burnt Predictor")
st.caption("Enter your profile and workout readings to estimate calories burnt.")

st.markdown("---")

col1, col2 = st.columns(2)

with col1:
    st.markdown("### Profile")
    gender = st.selectbox("Gender", ["Male", "Female"])
    age = st.slider("Age", 18, 60, 30)
    weight = st.slider("Weight (kg)", 42.0, 120.0, 75.0)

with col2:
    st.markdown("### Workout Readings")
    duration = st.slider("Duration (minutes)", 5.0, 30.0, 20.0)
    heart_rate = st.slider("Average Heart Rate (bpm)", 80.0, 160.0, 120.0)
    body_temp = st.slider("Body Temperature (°C)", 36.5, 41.5, 38.0)

st.markdown("---")

if st.button("🔥 Predict Calories", type="primary"):
    gender_enc = le.transform([gender])[0]
    new_data = pd.DataFrame(
        [[gender_enc, age, weight, duration, heart_rate, body_temp]],
        columns=FEATURES,
    )
    pred = float(model.predict(new_data)[0])

    st.markdown(
        f"""
        <div style="background-color:#E8604C22; border:2px solid #E8604C;
                    border-radius:12px; padding:26px; text-align:center; margin-top:10px;">
            <div style="font-size:13px; letter-spacing:2px; color:#8A5A4C; text-transform:uppercase;">
                Predicted Calories Burnt
            </div>
            <div style="font-size:58px; font-weight:bold; color:#C7482F; line-height:1.2;">
                {pred:.0f} <span style="font-size:26px;">kcal</span>
            </div>
            <div style="font-size:15px; color:#8A5A4C;">
                {duration:.0f} min &middot; {heart_rate:.0f} bpm avg &middot; {gender}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if show_comparison:
        st.markdown("#### Your workout vs. the dataset average")
        fig, ax = plt.subplots(figsize=(7, 2.6))
        fig.patch.set_facecolor("#FBF7F2")
        ax.set_facecolor("#FBF7F2")

        labels = ["Dataset average", "Your workout"]
        values = [avg_calories, pred]
        colors = ["#D9C3B8", "#E8604C"]
        bars = ax.barh(labels, values, color=colors, height=0.5, zorder=3)
        for bar, val in zip(bars, values):
            ax.text(val + max(values) * 0.02, bar.get_y() + bar.get_height() / 2,
                     f"{val:.0f} kcal", va="center", fontsize=12, fontweight="bold", color="#3A2A22")

        ax.set_xlim(0, max(values) * 1.25)
        ax.tick_params(axis="y", labelsize=12, colors="#3A2A22")
        ax.tick_params(axis="x", labelsize=9, colors="#8A5A4C")
        for spine in ["top", "right", "left"]:
            ax.spines[spine].set_visible(False)
        ax.spines["bottom"].set_color("#EAD9CE")
        ax.grid(axis="x", color="#F0E4DB", linewidth=0.7, zorder=0)
        ax.set_axisbelow(True)
        fig.tight_layout()

        st.pyplot(fig)
        diff = pred - avg_calories
        direction = "above" if diff >= 0 else "below"
        st.caption(f"That's {abs(diff):.0f} kcal {direction} the average session in this dataset.")
